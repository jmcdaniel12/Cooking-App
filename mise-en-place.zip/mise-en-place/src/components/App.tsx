'use client'
import { useStore } from '@/store'
import Sidebar from './Sidebar'
import Toast from './ui/Toast'
import { useToast } from '@/hooks/useToast'
import InspirePage from './pages/InspirePage'
import PlannerPage from './pages/PlannerPage'
import RecipesPage from './pages/RecipesPage'
import GroceryPage from './pages/GroceryPage'
import PantryPage from './pages/PantryPage'
import LeftoversPage from './pages/LeftoversPage'

export default function App() {
  const { currentPage } = useStore()
  const { message, toast } = useToast()

  const pages: Record<string, React.ReactNode> = {
    inspire: <InspirePage toast={toast} />,
    planner: <PlannerPage toast={toast} />,
    recipes: <RecipesPage toast={toast} />,
    grocery: <GroceryPage toast={toast} />,
    pantry: <PantryPage toast={toast} />,
    leftovers: <LeftoversPage toast={toast} />,
  }

  return (
    <div className="flex h-screen overflow-hidden bg-[#FAF8F3]">
      <Sidebar />
      <main className="flex-1 overflow-y-auto">
        {pages[currentPage] ?? pages['inspire']}
      </main>
      <Toast message={message} />
    </div>
  )
}
